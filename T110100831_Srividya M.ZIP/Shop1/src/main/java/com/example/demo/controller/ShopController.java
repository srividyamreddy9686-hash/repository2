package com.example.demo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.Shop;
import com.example.demo.service.ShopService;

@RestController
@RequestMapping("/shop")
public class ShopController {

    @Autowired
    ShopService sservice;

    // ADD
    @PostMapping("/add")
    public Shop addShop(@RequestBody Shop shop) {
        return sservice.addShop(shop);
    }

    // GET ALL
    @GetMapping("/get")
    public List<Shop> getShops() {
        return sservice.getShops();
    }

    // GET BY ID
    @GetMapping("/get/{id}")
    public Shop getShopById(@PathVariable Long id) {
        return sservice.getShopById(id);
    }

    // UPDATE
    @PutMapping("/update/{id}")
    public Shop updateShop(@PathVariable Long id, @RequestBody Shop shop) {
        return sservice.updateShop(id, shop);
    }

    // DELETE
    @DeleteMapping("/delete/{id}")
    public String deleteShop(@PathVariable Long id) {
        return sservice.deleteShop(id);
    }
}
