package com.example.demo.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Shop;
import com.example.demo.repository.ShopRepository;

@Service
public class ShopService {

    @Autowired
    ShopRepository srepo;

    // ADD
    public Shop addShop(Shop shop) {
        return srepo.save(shop);
    }

    // GET ALL
    public List<Shop> getShops() {
        return srepo.findAll();
    }

    // GET BY ID
    public Shop getShopById(Long id) {
        return srepo.findById(id).orElse(null);
    }

    // UPDATE
    public Shop updateShop(Long id, Shop shop) {
        Shop existing = srepo.findById(id).orElse(null);

        if (existing != null) {
            existing.setShopId(shop.getShopId());
            existing.setShopCategory(shop.getShopCategory());
            existing.setShopEmployeeId(shop.getShopEmployeeId());
            existing.setShopName(shop.getShopName());
            existing.setCustomers(shop.getCustomers());
            existing.setShopStatus(shop.getShopStatus());
            existing.setShopOwner(shop.getShopOwner());
            existing.setLeaseStatus(shop.getLeaseStatus());

            return srepo.save(existing);
        }

        return null;
    }

    // DELETE
    public String deleteShop(Long id) {
        srepo.deleteById(id);
        return "Shop deleted successfully";
    }
}
